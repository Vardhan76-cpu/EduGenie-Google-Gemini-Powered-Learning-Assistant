# Brainstorming & Idea Prioritization Template

| Parameter | Details |
| :--- | :--- |
| **Date** | 07 JULY 2026 |
| **Team ID** | xxxxxx |
| **Project Name** | EduGenie Google Gemini Powered Learning Assistant |
| **Maximum Marks** | 3 Marks |

---

## Step 1: Brainstorm and Idea Listing

Each team member lists out as many ideas as possible without judging them at this stage.

| S.No | Team Member | Idea / Suggestion | Category | Group No. |
| :--- | :--- | :--- | :--- | :--- |
| 1 | **Poojitha Varri** | AI-powered personalized learning assistant using Google Gemini | AI in Education | 1 |
| 2 | **Poojitha Varri** | Instant doubt-solving chatbot with voice and text support | AI Chatbot | 1 |
| 3 | **Poojitha Varri** | Automatic quiz and test generation from study material | Assessment | 2 |
| 4 | **Poojitha Varri** | Smart study planner with reminders and progress tracking | Productivity | 3 |
| 5 | **Poojitha Varri** | Multilingual explanation of concepts | Language Support | 1 |
| 6 | **Poojitha Varri** | AI-generated notes and summaries | Study Resources | 2 |

---

## Step 2: Idea Prioritization

Rate each grouped idea on feasibility and importance, then select the final idea(s) to move forward with.

| Group No. | Final Idea | Feasibility (High/Medium/Low) | Importance (High/Medium/Low) | Priority | Selected (Yes/No) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1** | EduGenie – Google Gemini Powered Learning Assistant | High | High | 1 | **Yes** |
| **2** | AI Quiz & Notes Generator | High | Medium | 2 | **No** |
| **3** | Smart Study Planner | Medium | Medium | 3 | **No** |
